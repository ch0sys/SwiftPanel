<?php //004d4
// WARNING: This script is protected. Any attempt to reverse engineer, debug or de-code this file or its dependent files is strictly prohibited.
// @package SWIFT Panel Version 1.6.1
// @Copyright (C) 2008-2009 SWIFT Panel All rights reserved
// @link http://www.swiftpanel.com
// @date 2010-8-14
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');@dl($__ln);if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV55tKGPNy8BhQ/MxKjfEA92IApIq6/WD85BSxX8JsoW0ENPeY2vGuwYpzNxD16tjHSg47lhzh
N04C42dpbCbVMOKgXpc9pDmVvdJbG1GEMtTmcx82ilR40UVN8ZwUwof3eS69zI8MXwlKH6dW592l
mTjOQWUcsB0+blyWWrV+AekZStW9QwJ1AM8/i+l1G3kS+9O2hFOZUW6kVFfcoHOOt4fKcekC/gTr
C9On1NcWA0BH43f8WfI4ZNhnNaQwRWFwznqwY8qX1DkL6aOGBkHxGVW1KoERR1DPqX4Y7h9bykM0
3r3GWrELwYP8PGfrZu/SNpFNY3LJDyvz4q00dS9e/0dMdZ7ZGlnLwR6dp+lKYGxHSpctVULcFLYc
YplXnGian81LmaM8wxSzFtUtpOxiq44ePC5rltf9B2BKX5smfva0zniouRf0hjsVEAklGjQchWdZ
U/HDSo50hTCGmD559jA3ETlYnbvVcv67J5VNcqSnTXXxg9InzW5jGPh6l3TBKeS=